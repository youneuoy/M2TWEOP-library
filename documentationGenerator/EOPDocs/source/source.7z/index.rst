.. M2TWEOP documentation master file, created by
   sphinx-quickstart on Thu Apr 22 15:18:38 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to M2TWEOP's documentation!
===================================


.. raw:: html

	<div align="center">
		<a href="https://www.twcenter.net/forums/forumdisplay.php?2296-M2TW-Engine-Overhaul-Project"><img src="_static/M2TWEOP.png" width="1920" alt="EOP" /></a>
		<br>
		<br>
	  <p>
	  	<a href="https://www.twcenter.net/forums/forumdisplay.php?2296-M2TW-Engine-Overhaul-Project"><img src="_static/twc.png" alt="TWC" width="250" height="70"/></a>
		<a href="https://discord.gg/Epqjm8u2WK"><img src="_static/discorsd.png" alt="Discord server" width="250" height="70"></a>
		<a href="https://www.youtube.com/channel/UCMyHomaKeeGR4ZPGrBo9dYw"><img src="_static/youtube.png" alt="YouTube" width="250" height="70"/></a>
	  </p>
	</div>

`M2TWEOP LUA plugin docs <_static/LuaLib/index.html>`_
---------------------------------------------------------------------------------------------------------------------------------------------------------------

.. toctree::
	:maxdepth: 2


	M2TWEOP.md





